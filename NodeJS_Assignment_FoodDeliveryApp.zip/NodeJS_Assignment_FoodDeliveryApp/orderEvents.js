const EventEmitter=require('events');
const eventEmitter=new EventEmitter();

eventEmitter.on('orderReady',(orderId)=>{
    console.log(`order with ID ${orderId} is ready`);
});

module.exports=eventEmitter;
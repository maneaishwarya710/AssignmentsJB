const express=require('express');
const router=express.Router();
const orderController=require('./orderController');

router.post('/', orderController.acceptNewOrder);

router.get('/:id', orderController.getOrderStatus);

module.exports=router;
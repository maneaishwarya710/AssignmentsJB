const app=require('./index');

const PORT=4500;

app.listen(PORT, ()=>{
    console.log("Running on port 4500");
});

app.get('/', (req, res) => {
    res.send('Hello, World!');
});
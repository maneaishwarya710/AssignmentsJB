let orders = [];

module.exports = {
    createOrder(orderData, callback) {
        const newOrder = {
            id: orders.length + 1,
            ...orderData,
            status: 'accepted'
        };
        orders.push(newOrder);
        setTimeout(() => {
            callback(newOrder);
        }, 500);
    },
    processOrder(orderId) {
        return new Promise((resolve, reject) => {
            const order = orders.find(o => o.id === orderId);
            if (!order) {
                return reject('Order not found');
            }
            console.log('processing');
            setTimeout(() => {
                order.status = 'OrderReady';
                resolve();
            }, 5000);
        });
    },
    getOrderStatus(orderId) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const order = orders.find(o => o.id === orderId);
                if (!order) {
                    return resolve(null);
                }
                resolve(order.status);
            }, 15000);
        });
    }
};
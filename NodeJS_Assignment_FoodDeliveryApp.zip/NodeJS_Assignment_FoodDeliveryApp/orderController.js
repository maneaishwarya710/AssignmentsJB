const Order = require('./orderModel');
const orderEvents = require('./orderEvents');

exports.acceptNewOrder = (req, res) => {
    const orderData = req.body;

    function orderAcceptedCallback(order) {
        res.status(201).json({
            message: 'Order accepted successfully',
            order: order
        });
    }

    Order.createOrder(orderData, orderAcceptedCallback);

    Order.processOrder(orderData.id)
        .then(() => {
            orderEvents.emit('orderReady', orderData.id);
        })
        .catch((err) => {
            console.error('Error processing order:', err);
        });
};

exports.getOrderStatus = async (req, res) => {
    try {
        const orderId = parseInt(req.params.id, 10);
        const status = await Order.getOrderStatus(orderId);
        if (!status) {
            return res.status(404).json({ message: 'Order not found' });
        }
        res.json({ orderId, status });
    } catch (error) {
        res.status(500).json({ message: 'Internal server error', error });
    }
};
import { AppDataSource } from "./config/data-source";
import express from 'express';
import userRoutes from "./routes/userRoutes";
import 

const app=express();
app.use(express.json())

app.use("/user",userRoutes)

AppDataSource.initialize().then(() => {
    app.listen(3002, () => {
        console.log("Running on port 3002");
    });
}).catch((err) => {
    console.error("Error during Data Source initialization:", err);
});
import "reflect-metadata";
import { DataSource } from "typeorm";
import * as dotenv from "dotenv";
import { Order } from "../entities/orders";
import { Product } from "../entities/product";
import { Profile } from "../entities/profile";
import { User } from "../entities/user";


dotenv.config();

export const AppDataSource=new DataSource({
    type:"mssql",
    port:Number(process.env.DB_PORT),
    username:process.env.DB_USER,
    password:process.env.DB_PASSWORD,
    host:process.env.DB_HOST,
    database:process.env.DB_NAME,
    entities:[Order, Product, Profile, User],
    logging:true,
    synchronize:false,
    options:{
        trustServerCertificate:true,
        connectTimeout:30000
    }
});




import { Order } from "../entities/orders";
import { User } from "../entities/user";
import { Profile } from "../entities/profile";
import { profileRepository } from "../repositories/profileRepository";
import { userRepository } from "../repositories/userRepository";

export class UserService{
    async createUser(){
        const profile=profileRepository.create({details:"Here is details"});
        await profileRepository.save(profile);

        const user=userRepository.create({name:"hina", profile});
        return await userRepository.save(user);
    }
}
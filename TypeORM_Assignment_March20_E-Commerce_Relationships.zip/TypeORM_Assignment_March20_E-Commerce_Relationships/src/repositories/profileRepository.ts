import { AppDataSource } from "../config/data-source";
import 'reflect-metadata'
import { Profile } from "../entities/profile";

export const profileRepository=AppDataSource.getRepository(Profile);
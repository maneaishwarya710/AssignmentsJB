import { AppDataSource } from "../config/data-source";
import 'reflect-metadata'
import { Order } from "../entities/orders";

export const orderRepository=AppDataSource.getRepository(Order);
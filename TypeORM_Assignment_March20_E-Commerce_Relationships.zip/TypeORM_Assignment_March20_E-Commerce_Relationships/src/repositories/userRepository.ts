import { AppDataSource } from "../config/data-source";
import 'reflect-metadata'
import { User } from "../entities/user";

export const userRepository=AppDataSource.getRepository(User);
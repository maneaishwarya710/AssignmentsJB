import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinColumn, JoinTable, OneToOne } from "typeorm";
import 'reflect-metadata';
import { Order } from "./orders";
import { Profile } from "./profile";

@Entity({name:"rUser"})
export class User{

    @PrimaryGeneratedColumn()
    id:number

    @Column({default:'abc'})
    name:string

    @ManyToMany(()=>Order, (order)=>order.user)
    @JoinTable()
    orders:Order[];

    @OneToOne(()=>Profile, ((profile)=>profile.user))
    profile:Profile
}


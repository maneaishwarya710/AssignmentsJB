import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinColumn, JoinTable, ManyToOne } from "typeorm";
import 'reflect-metadata';
import { Order } from "./orders";

@Entity({name:"rProduct"})
export class Product{

    @PrimaryGeneratedColumn()
    id:number

    @Column({default:'default_name'})
    name:string

    @Column({default:'default_price'})
    price:number
}


import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinColumn, JoinTable, ManyToOne } from "typeorm";
import 'reflect-metadata';
import { User } from "./user";
import { Profile } from "./profile";
import { Product } from "./product";

@Entity({name:"rOrders"})
export class Order{

    @PrimaryGeneratedColumn()
    id:number

    @Column({default:'default_quantity'})
    quantity:number

    @Column({default:'default_price'})
    price:number

    @ManyToMany(()=>Product)
    @JoinTable({
        name: "OrderItem", 
        joinColumn: {
            name: "order_id", 
            referencedColumnName: "id" 
        },
        inverseJoinColumn: {
            name: "product_id", 
            referencedColumnName: "id" 
        }
    })
    product:Product[];

    @ManyToOne(() => User, (user) => user.orders)
    user: User;
}


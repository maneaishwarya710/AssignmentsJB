import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinColumn, JoinTable, OneToOne } from "typeorm";
import 'reflect-metadata';
import { User } from "./user";

@Entity({name:"rProfile"})
export class Profile{

    @PrimaryGeneratedColumn()
    id:number

    @Column({default:'abc'})
    details:string

    @OneToOne(()=>User, ((user)=>user.profile))
    user:User
}


const express = require('express');
const { Request, Response } = express;
// import { UserService } from '../services/userServices';
const userService = require('../services/userServices');

// const userService = new UserService();

export class UserController {
    async createUser(req, res) {
        try {
            const user = await userService.createUser();
            res.status(201).json(user);
        } catch (error) {
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    // async createUser(req, res) {
    //     try {
    //         const { name, details } = req.body;

    //         // Ensure req.body is correctly typed
    //         if (typeof name !== 'string' || typeof details !== 'string') {
    //             return res.status(400).json({ error: 'Invalid input' });
    //         }

    //         const user = await userService.createUser(name, details);
    //         res.status(201).json(user);
    //     } catch (error) {
    //         res.status(500).json({ error: 'Internal Server Error' });
    //     }
    // }

}
import { Router } from "express";
import { BookController } from "../controllers/bookController";

const router = Router();
const bookController = new BookController();

router.post("/books", bookController.createBook);

router.delete("/delete/:id", bookController.deleteBook);

router.put("/update/:id", bookController.updateBook);

router.get("/find/:id", bookController.findBookById);
export default router;
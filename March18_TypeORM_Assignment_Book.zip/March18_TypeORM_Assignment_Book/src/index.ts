import express from "express";
import { AppDataSource } from "./config/database";
import bookRoutes from "./routes/bookRoutes";

const app = express();
app.use(express.json());
app.use('/b',bookRoutes);

AppDataSource.initialize().then(() => {
    app.listen(3001, () => {
        console.log("Running on port 3001");
    });
}).catch((err) => {
    console.error("Error during Data Source initialization:", err);
});
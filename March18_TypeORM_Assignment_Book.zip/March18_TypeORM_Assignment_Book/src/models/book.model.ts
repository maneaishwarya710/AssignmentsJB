import { Column, Entity, Int32, PrimaryGeneratedColumn } from "typeorm";
import "reflect-metadata";

@Entity()
class Book33{
    @PrimaryGeneratedColumn()
    id:number;
    @Column({type:"varchar"})
    title:string;
    @Column({type:"varchar"})
    author:string;
    @Column({type:"date"})
    publishedYear:Date;
    @Column({type:"int"})
    price:number
}

export default Book33;
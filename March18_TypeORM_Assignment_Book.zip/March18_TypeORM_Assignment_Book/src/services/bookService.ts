import { DeepPartial } from "typeorm";
import { bookRepository } from "../repositories/bookRepository";
import Book33 from "../models/book.model";

export class BookService {
    async createBook(bookData: DeepPartial<Book33>) {
        const book = bookRepository.create(bookData);
        await bookRepository.save(book);
        return book;
    }

    async updateBook(id: number, bookData: DeepPartial<Book33>) {
        await bookRepository.update(id, bookData);
        const updatedBook = await bookRepository.findOne({ where: { id } });
        return updatedBook;
    }

    async findBookById(id: number) {
        const book = await bookRepository.findOne({ where: { id } });
        return book;
    }

    async deleteBook(id: number) {
        await bookRepository.delete(id);
        return { message: "Book deleted successfully" };
    }
}
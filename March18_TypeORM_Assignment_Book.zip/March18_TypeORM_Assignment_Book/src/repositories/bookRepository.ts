import { AppDataSource } from "../config/database";
import Book33 from "../models/book.model";
export const bookRepository = AppDataSource.getRepository(Book33);
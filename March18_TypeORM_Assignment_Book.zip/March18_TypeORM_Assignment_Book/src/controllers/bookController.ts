import { Request, Response } from "express";
import { BookService } from "../services/bookService";

const bookService = new BookService();

export class BookController {
    async createBook(req: Request, res: Response) {
        const book = await bookService.createBook(req.body);
        res.json(book);
    }

    async updateBook(req: Request, res: Response) {
        const { id } = req.params;
        const updatedBook = await bookService.updateBook(Number(id), req.body);
        res.json(updatedBook);
    }

    async findBookById(req: Request, res: Response) {
        const { id } = req.params;
        const book = await bookService.findBookById(Number(id));
        res.json(book);
    }

    async deleteBook(req: Request, res: Response) {
        const { id } = req.params;
        const result = await bookService.deleteBook(Number(id));
        res.json(result);
    }
}
import { Injectable } from '@angular/core';

interface FoodItem{
  id:number;
  name:string;
  price:number;
}

@Injectable({
  providedIn: 'root'
})

export class CartService {
  private cart:FoodItem[]=[];

  addToCart(foodItem:FoodItem):void{
    this.cart.push(foodItem);
  }

  removeFromCart(foodItem:FoodItem):void{
    this.cart=this.cart.filter(item=>item.id!==foodItem.id);
  }

  getCartItems():FoodItem[]{
    return this.cart;
  }

  getTotalPrice():number{
    return this.cart.reduce((total,item)=>total+item.price,0);
  }
}

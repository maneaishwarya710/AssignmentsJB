import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FoodCartComponent } from './food-cart/food-cart.component';
import { CommonModule } from '@angular/common';
import { NO_ERRORS_SCHEMA } from '@angular/core';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FoodCartComponent, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'FoodDeliveryApp';
}

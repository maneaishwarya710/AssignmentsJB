import { Component } from '@angular/core';
import { CartService } from '../cart.service';
import { CommonModule } from '@angular/common';
import { NO_ERRORS_SCHEMA } from '@angular/core';

interface FoodItem{
  id:number;
  name:string;
  price:number;
}

@Component({
  selector: 'app-food-cart',
  imports: [CommonModule],
  templateUrl: './food-cart.component.html',
  styleUrl: './food-cart.component.css'
})
export class FoodCartComponent {
  foodItems:FoodItem[]=[
    {id:1, name:'Panipuri', price:50},
    {id:2, name:'Bhel', price:40},
    {id:3, name:'Chat', price:90},
    {id:4, name:'Gulabjamun', price:150},
  ];

  constructor(private cartService:CartService){}

  addtoCart(item:FoodItem):void{
    this.cartService.addToCart(item);
  }

  removeFromCart(item:FoodItem):void{
    this.cartService.removeFromCart(item);
  }

  getCartItems():FoodItem[]{
    return this.cartService.getCartItems();
  }

  getTotalPrice():number{
    return this.cartService.getTotalPrice();
  }
}

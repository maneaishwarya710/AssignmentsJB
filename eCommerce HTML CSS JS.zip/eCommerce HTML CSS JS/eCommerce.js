const sampleProducts = [
    { id: 6, name: "TV", category: "Electronics", price: 15000, rating: 3, imageURL: "tv.png" },
    { id: 1, name: "Refrigerator", category: "Electronics", price: 25000, rating: 4, imageURL: "rg.png" },
    { id: 3, name: "Washing Machine", category: "Electronics", price: 18000, rating: 3, imageURL: "wm.png" },
    { id: 5, name: "Laptop", category: "Electronics", price: 70000, rating: 5, imageURL: "laptop.png" },
    { id: 7, name: "Ear Buds", category: "Electronics", price: 1000, rating: 2, imageURL: "earB.png" },
    { id: 8, name: "Smartphone", category: "Electronics", price: 50000, rating: 4, imageURL: "smartphone.png" },
    { id: 9, name: "Tablet", category: "Electronics", price: 30000, rating: 4, imageURL: "tablet.png" },
    { id: 10, name: "Smartwatch", category: "Electronics", price: 12000, rating: 4, imageURL: "watch.png" },
    { id: 2, name: "Oven", category: "Electronics", price: 20000, rating: 5, imageURL: "oven.png" },
    { id: 4, name: "Speaker", category: "Electronics", price: 14000, rating: 5, imageURL: "speaker.png" }
];

class ElectroFair {
    constructor() {
        this.products = sampleProducts;
        this.cart = this.loadCart();
        this.displayProducts(this.products);
        this.updateCartSummary();
    }

    // Display products
    displayProducts(products) {
        const productGrid = document.querySelector('.product_grid');
        productGrid.innerHTML = '';
        products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.classList.add('product');
            productDiv.innerHTML = `
                <img src="${product.imageURL}" alt="${product.name}" class="product-img">
                <h3>${product.name}</h3>
                <h4>Rs. ${product.price}</h4>
                <button type="button" class="cartB" data-id="${product.id}">Add to cart</button>
            `;
            productGrid.appendChild(productDiv);
        });
        this.addEventListeners();
    }

    // Add event listeners to buttons
    addEventListeners() {
        document.querySelectorAll('.cartB').forEach(button => {
            button.addEventListener('click', () => {
                const productId = button.getAttribute('data-id');
                this.addProductToCart(parseInt(productId));
            });
        });

        document.getElementById('categoryFilter').addEventListener('change', () => {
            this.filterProducts();
        });
        document.getElementById('priceFilter').addEventListener('change', () => {
            this.filterProducts();
        });
        document.getElementById('sortFilter').addEventListener('change', () => {
            this.sortProducts();
        });
    }

    // Filter products by category and price range
    filterProducts() {
        const category = document.getElementById('categoryFilter').value;
        const priceRange = document.getElementById('priceFilter').value;

        let filteredProducts = this.products;

        if (category !== 'all') {
            filteredProducts = filteredProducts.filter(product => product.category.toLowerCase() === category.toLowerCase());
        }

        if (priceRange !== 'all') {
            const [minPrice, maxPrice] = priceRange.split('-');
            filteredProducts = filteredProducts.filter(product => {
                if (maxPrice) {
                    return product.price >= minPrice && product.price <= maxPrice;
                }
                return product.price >= minPrice;
            });
        }

        this.displayProducts(filteredProducts);
    }

    // Sort products by price and rating
    sortProducts() {
        const sortValue = document.getElementById('sortFilter').value;
        let sortedProducts = [...this.products];

        if (sortValue === 'priceLow') {
            sortedProducts.sort((a, b) => a.price - b.price);
        } else if (sortValue === 'priceHigh') {
            sortedProducts.sort((a, b) => b.price - a.price);
        } else if (sortValue === 'ratingHigh') {
            sortedProducts.sort((a, b) => b.rating - a.rating);
        }

        this.displayProducts(sortedProducts);
    }

    // Add product to cart
    addProductToCart(id) {
        const product = this.products.find(p => p.id === id);
        if (product) {
            this.cart.push(product);
            this.saveCart();
            this.updateCartSummary();
            console.log("Product added to cart successfully");
        } else {
            console.log("Product is not available");
        }
    }

    // Update cart summary and save cart in storage
    updateCartSummary() {
        const cartSummary = document.getElementById('cartSummary');
        const cartItems = cartSummary.querySelector('#cartItems');
        const totalAmount = cartSummary.querySelector('#totalAmount');

        cartItems.innerHTML = '';
        this.cart.forEach(item => {
            const listItem = document.createElement('li');
            listItem.textContent = `${item.name} - Rs. ${item.price}`;
            cartItems.appendChild(listItem);
        });

        const total = this.cart.reduce((acc, item) => acc + item.price, 0);
        totalAmount.textContent = total;
    }

    // Save cart to local storage
    saveCart() {
        localStorage.setItem('cart', JSON.stringify(this.cart));
    }

    // Load cart from local storage
    loadCart() {
        const cart = localStorage.getItem('cart');
        return cart ? JSON.parse(cart) : [];
    }
}

const electroFair = new ElectroFair();

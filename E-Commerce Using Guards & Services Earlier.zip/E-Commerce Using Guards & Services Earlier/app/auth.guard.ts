import { CanActivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthService } from './auth.service';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const isAuthenticated=localStorage.getItem('loggedIn')==='true';
    if(!isAuthenticated){
      alert('First Login')
      this.router.navigate(['/login']);
      return false;
    }
    
    return true;
  }

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot):boolean {
    const isAuthenticated=localStorage.getItem('loggedIn')==='true';
    const role=localStorage.getItem('role');
    if(!isAuthenticated){
      alert('First Login')
      this.router.navigate(['/login']);
      return false;
    }
    else
      if(role!=='Admin'){
        alert("Only Admins can acceess");
        return false;
      }
    
    return true;
  }
}
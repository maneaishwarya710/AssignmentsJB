import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private rolePermissions: { [key: string]: string[] } = {
    Admin: ['dashboard', 'orders', 'products', 'users'],
    Manager: ['dashboard', 'orders', 'products'],
    CustomerSupport: ['dashboard', 'orders'],
  };

  private currentUserRole: string | null = null;

  constructor(private router: Router) {}

  login(user: string) {
    if(user==='Admin')
    {
      localStorage.setItem('loggedIn', 'true');
      this.router.navigate(['/dashboard']);
    }
    else{
      alert("Only for admin");
    }
  }

  logout() {
    localStorage.setItem('loggedIn', 'false');
    this.router.navigate(['/login']);
  }

  isLoggedIn(): boolean {
    return localStorage.getItem('loggedIn') === 'true';
  }

  getRole(): string {
    if (!this.currentUserRole) {
      this.currentUserRole = localStorage.getItem('role');
    }
    return this.currentUserRole || '';
  }

  hasPermission(route: string): boolean {
    const role = this.getRole();
    return role ? this.rolePermissions[role]?.includes(route) || false : false;
  }

  
}
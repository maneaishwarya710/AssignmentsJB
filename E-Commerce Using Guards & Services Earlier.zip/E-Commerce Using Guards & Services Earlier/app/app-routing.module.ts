import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserModule } from './user/user.module';
import { LoginComponent } from './user/login/login.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './auth.guard';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { FormsModule } from '@angular/forms';

const routes: Routes = [
  { path: 'user', loadChildren: () => import('./user/user.module').then(m => m.UserModule) },
  { path: 'product', loadChildren: () => import('./product/product.module').then(m => m.ProductModule), canActivateChild:[AuthGuard], data:{role:'Manager'} },
  { path: 'order', loadChildren: () => import('./order/order.module').then(m => m.OrderModule), canActivateChild:[AuthGuard], data:{role:'Manager'} },
  { path: '**', redirectTo: 'home' },
  {path: '', component: HomeComponent},
  {path:'403', component:ForbiddenComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes), FormsModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }

const fm=require('./fileManager');

fm.Fun1();





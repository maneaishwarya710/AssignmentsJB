const fs=require('fs');
const path=require('path');

//Global Objects
console.log("Using global objects:")
console.log(__filename);
console.log(__dirname);
console.log(process.pid);
console.log(process.platform);
console.log(process.version);
console.log(process.cwd);

fs.writeFile('notes.txt', "This is my file", (err)=>{
    console.log("File created successfully!");
    console.log("File written successfully!");
});

const readFileFun = () => {
    fs.readFile('notes.txt', 'utf-8', (err, data) => {
        if (err) throw err;
        console.log(data);
    });
};

readFileFun();

fs.appendFile('notes.txt', '\n This is appended data!', (err)=>{
    if(err) throw err;
    console.log("Content appended!");
}
);

// fs.unlink('s.txt', (err)=>{
//     if(err) throw err;
//     console.log("The file deleted!");
// }
// );

console.log(path.basename('C:/Users/AishwaryaManeINDev/Downloads/Day1.pdf'));
console.log(path.dirname('C:/Users/AishwaryaManeINDev/Downloads/Day1.pdf'));

//reading file with 3 sec delay
fs.readFile('notes.txt', 'utf-8', (err, data)=>{
    if (err) {
        throw err;
    }
    console.log('reading file with 3 sec delay');
    setTimeout(()=>{
        console.log(data);
    },3000);
});

// setInterval(()=>{
//     console.log('System is running...');
// }, 5000);

//buffers
const buff=new Buffer.alloc(50);
buff.write('Written to buffer', 0, 'utf8');
console.log(buff.toString());

const fun1=()=>fs.readFile('notes.txt', 'utf-8', (err, data)=>{
    if (err) {
        throw err;
    }
    const buff=data.toString();
    console.log(buff);
});

fun1();

module.exports={readFileFun, fun1};
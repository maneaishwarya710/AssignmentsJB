const fs=require('fs');

const readStream=fs.createReadStream('notes.txt', 'utf8');

readStream.on('data', (chunks)=>{
    console.log(chunks);
});

readStream.on('error', (err)=>{
    console.log(err)
});

const writeSteam=fs.createWriteStream('j.txt');
writeSteam.write("This is written to write stream");

readStream.pipe(writeSteam);

writeSteam.end(()=>{
    console.log("Data written successfully!");
})

const zlib=require('zlib');
const gzip=zlib.createGzip();
const writeSteam1=fs.createWriteStream('j.txt.zip');
readStream.pipe(gzip).pipe(writeSteam1);


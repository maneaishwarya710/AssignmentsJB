import { Component } from '@angular/core';
import { Order } from './order.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'AngularExam1';

  order:Order[]=[{productName:'Laptop', quantity:1},{productName:'Hand Bag', quantity:2},{productName:'yoga Mats', quantity:6}];

  // shippingStatus='';
  parentObservable=new Observable<string>();
  subscription:any;
  receiveShippingStatus(status:Observable<string>){
    // this.shippingStatus=msg;
    // console.log('Order will be received at:',msg);
    this.subscription=status.subscribe(value=>console.log(value));
  }
}

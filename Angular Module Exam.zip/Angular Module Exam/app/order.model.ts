export interface Order{
    productName:string;
    quantity:number;
}
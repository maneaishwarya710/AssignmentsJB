import { Component, Input, Output, EventEmitter} from '@angular/core';
import { Order } from '../order.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-order-item',
  standalone: false,
  templateUrl: './order-item.component.html',
  styleUrl: './order-item.component.css'
})
export class OrderItemComponent {
  @Input() orderListFromParent:Order[]=[];

  statusObservable=new Observable<string>(observer=>{
    observer.next("Order Status:");
    setTimeout(()=>observer.next('Order Placed!'), 1000);
    setTimeout(()=>observer.next('Shipped!'), 2000);
    setTimeout(()=>observer.next('In Transit!'), 4000);
    setTimeout(()=>observer.next('Delivered!'), 6000);
    setTimeout(()=>observer.complete(),7000);
  });

  // @Output() emitter: EventEmitter<any> = new EventEmitter();
  @Output() emitter: EventEmitter<Observable<string>> = new EventEmitter();

  sendStatusToParent(){
    this.emitter.emit(this.statusObservable);
  }
}

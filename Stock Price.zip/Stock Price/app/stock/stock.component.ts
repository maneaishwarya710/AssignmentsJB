import { Component, OnDestroy } from '@angular/core';
import { interval, Subject, Subscription, map } from 'rxjs';

@Component({
  selector: 'app-stock',
  standalone: false,
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']  // Corrected here
})
export class StockComponent implements OnDestroy {
  private stockPriceSubject = new Subject<number>();
  latestPrice: number | null = null;
  subscription: Subscription | null = null;
  count: number = 0;

  constructor() {
    interval(2000)
      .pipe(map(() => (Math.random() * 1000).toFixed(2)))
      .subscribe(price => {
        console.log('New stock price', price);
        this.stockPriceSubject.next(parseFloat(price));
      });
  }

  subscribeToUpdates() {
    this.subscription = this.stockPriceSubject.subscribe(price => {
      this.latestPrice = price;
      console.log('Received stock price:', price);
    });
    this.count++;
  }

  unsubscribeFromUpdate() {
    this.subscription?.unsubscribe();
    this.count--;
    console.log('Unsubscribed from stock updates');
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();  // Corrected here
  }
}
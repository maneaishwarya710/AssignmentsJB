import { Component } from '@angular/core';

@Component({
  selector: 'app-product-management',
  standalone: false,
  
  templateUrl: './product-management.component.html',
  styleUrl: './product-management.component.css'
})
export class ProductManagementComponent {

}

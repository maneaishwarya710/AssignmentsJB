import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductManagementComponent } from '../product-management/product-management.component';
import { OrderManagementComponent } from '../order-management/order-management.component';
import { UserManagementComponent } from '../user-management/user-management.component';
import { RoleGuard } from '../role.guard';
import { ChildRoleGuard } from '../child-role.guard';
import { AdminComponent } from './admin.component';

const routes: Routes = [
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [RoleGuard],
    canActivateChild: [ChildRoleGuard],
    children: [
      { path: 'product-management', component: ProductManagementComponent },
      { path: 'order-management', component: OrderManagementComponent },
      { path: 'user-management', component: UserManagementComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
import { Component } from '@angular/core';

@Component({
  selector: 'app-order-management',
  standalone: false,
  
  templateUrl: './order-management.component.html',
  styleUrl: './order-management.component.css'
})
export class OrderManagementComponent {

}

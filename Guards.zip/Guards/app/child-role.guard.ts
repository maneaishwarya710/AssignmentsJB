import { Injectable } from "@angular/core";
import { CanActivateChild, Router } from "@angular/router";
import { AuthService } from "./auth.service";

@Injectable({
  providedIn: 'root'
})
export class ChildRoleGuard implements CanActivateChild {
  constructor(private authService: AuthService, private router: Router) {}

  canActivateChild(): boolean {
    const role = this.authService.getRole();

    if (role === 'Admin' || role === 'Manager') {
      return true;
    } else {
      this.router.navigate(['/forbidden']); 
      return false;
    }
  }
}
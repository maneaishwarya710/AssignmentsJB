import { Injectable } from '@angular/core';
import { CartServiceService } from '../cart.service';

interface Product{
  id:number;
  name:string;
  price:number;
}

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor() { }

  cart:Product[]=[];

  removeProductFromCart(product:Product):Product[]{
    this.cart=this.cart.filter(p1=>p1.id==product.id);
    return this.cart;
  }

  totalPrice():number{
    return this.cart.reduce((total,item)=>total+item.price,0);
  }
}

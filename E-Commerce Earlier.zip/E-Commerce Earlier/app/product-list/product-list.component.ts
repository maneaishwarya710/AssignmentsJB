import { Component } from '@angular/core';
import { CartServiceService } from '../cartservice.service';
import { CommonModule } from '@angular/common';

interface Product{
  id:number;
  name:string;
  price:number;
}

@Component({
  selector: 'app-product-list',
  imports: [CommonModule],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent {
  constructor(public cartSer:CartServiceService){};

  productList:Product[]=[
    {id:1,name:"Hair Dryer", price:500},
    {id:2,name:"Headphones", price:670},
    {id:3,name:"Water Bottle", price:100},
  ]

  addProductToCart(product:Product):void{
    this.cartSer.addProductToCart(product);
  }

  displayProducts():Product[]{
    return this.cartSer.displayProducts();
  }
}

import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CartComponentComponent } from './cart-component/cart-component.component';
import { CartServiceService } from './cartservice.service';
import { ProductListComponent } from './product-list/product-list.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,CartComponentComponent,ProductListComponent, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'ECommerce';
}

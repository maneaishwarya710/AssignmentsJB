import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartService } from '../cart.service';

interface Cart{
  id:number;
  name:string;
  price:number;
}

@Component({
  selector: 'app-cart-component',
  imports: [CommonModule],
  templateUrl: './cart-component.component.html',
  styleUrl: './cart-component.component.css',
  providers: [CartService]
})

export class CartComponentComponent {
  constructor(private cartService:CartService){};

  cart:Cart[]=[];

  removeProductFromCart(p1:Cart):void{
    this.cartService.removeProductFromCart(p1);
  }

  totalPrice():number{
    return this.cartService.totalPrice();
  }

}

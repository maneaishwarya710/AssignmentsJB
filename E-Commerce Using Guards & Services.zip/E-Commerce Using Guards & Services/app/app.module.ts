import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration, withEventReplay } from '@angular/platform-browser';
import { Router } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';

import { UserModule } from './user/user.module';



import { ProductDetailsComponent } from './product/product-details/product-details.component';
import { OrderDetailsComponent } from './order/order-details/order-details.component';
import { OrderListComponent } from './order/order-list/order-list.component';
import { ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from './user/dashboard/dashboard.component';
import { AuthService } from './auth/auth.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { UserRoutingModule } from './user/user-routing.module';

import { AdminModule } from './admin/admin.module';
import { ProductModule } from './product/product.module';
import { SharedModule } from './shared/shared.module';
import { SecurityModule } from './security/security.module';





@NgModule({
  declarations: [
    AppComponent,
    OrderDetailsComponent,
    OrderListComponent,
    DashboardComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    UserModule,
    ReactiveFormsModule,UserRoutingModule,  
    AdminModule,
    ProductModule,
    SharedModule,
    SecurityModule
  ],
  providers: [
    AuthService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

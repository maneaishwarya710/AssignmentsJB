import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SecuritySettingsComponent } from './security-settings/security-settings.component';
import { ManagerGuard } from '../auth/manager.guard';

const routes: Routes = [
  {path:'security-settings', component:SecuritySettingsComponent, canActivate:[ManagerGuard]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SecurityRoutingModule { }

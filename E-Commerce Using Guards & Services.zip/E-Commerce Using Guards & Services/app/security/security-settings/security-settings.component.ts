import { Component } from '@angular/core';

@Component({
  selector: 'app-security-settings',
  standalone: false,
  
  templateUrl: './security-settings.component.html',
  styleUrl: './security-settings.component.css'
})
export class SecuritySettingsComponent {

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SecurityRoutingModule } from './security-routing.module';
import { SecuritySettingsComponent } from './security-settings/security-settings.component';


@NgModule({
  declarations: [
    SecuritySettingsComponent
  ],
  imports: [
    CommonModule,
    SecurityRoutingModule
  ]
})
export class SecurityModule { }

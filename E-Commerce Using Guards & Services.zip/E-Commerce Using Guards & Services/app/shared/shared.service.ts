import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

interface Product {
  name: string;
  id: number;
  details: string;
  price: number;
  rating: number;
}

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor(private router:Router){}

  private productArray: Product[] = [
    { name: 'Headphones', id: 1, details: 'Experience unparalleled sound quality with the Bang & Olufsen Beoplay H95 headphones', price: 1250, rating: 4.5 },
    { name: 'Hair Dryer', id: 2, details: 'Philips HP8100/60 Compact Hair Dryer| 2 Flexible heat settings', price: 2500, rating: 4.0 },
    { name: 'Water Bottle', id: 3, details: 'Check the collection of bottles online available in different materials like steel, plastic, copper, aluminium, etc.', price: 790, rating: 3.5 }
  ];

  private favProductArray: Product[] = [];
  private BoughtProductArray:Product[]=[];

  getData(): Product[] {
    return this.productArray;
  }

  getFavProducts(): Product[] {
    return this.favProductArray;
  }

  getBoughtProducts(): Product[] {
    return this.BoughtProductArray;
  }

  addProduct(product: Product): void {
    if (!this.favProductArray.includes(product)) {
      this.favProductArray.push(product);
    }
  }

  removeProduct(product: Product): void {
    const index = this.favProductArray.indexOf(product);
    if (index > -1) {
      this.favProductArray.splice(index, 1);
    }
  }

  buyProduct(product:Product):void{
    this.BoughtProductArray.push(product);
    this.router.navigate(['/order/order-list']);
  }

  cancelOrder(product:Product):void{
    const index = this.BoughtProductArray.indexOf(product);
    if (index > -1) {
      this.favProductArray.splice(index, 1);
    }
  }
}

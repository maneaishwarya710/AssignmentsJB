import { Component } from '@angular/core';

@Component({
  selector: 'app-user-accounts',
  standalone: false,
  
  templateUrl: './user-accounts.component.html',
  styleUrl: './user-accounts.component.css'
})
export class UserAccountsComponent {

}

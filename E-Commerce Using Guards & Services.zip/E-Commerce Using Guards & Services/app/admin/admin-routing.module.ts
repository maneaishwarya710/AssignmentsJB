import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserAccountsComponent } from './user-accounts/user-accounts.component';
import { AdminGuard } from '../auth/admin.guard';

const routes: Routes = [
  {path:'user-accounts', component:UserAccountsComponent, canActivate:[AdminGuard]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }

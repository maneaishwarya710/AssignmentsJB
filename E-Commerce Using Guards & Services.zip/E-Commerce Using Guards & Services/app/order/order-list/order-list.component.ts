import { Component, OnInit } from '@angular/core';
import { SharedService } from '../../shared/shared.service';
import { CommonModule } from '@angular/common';

interface Product {
  name: string;
  id: number;
  details: string;
  price: number;
  rating: number;
}

@Component({
  selector: 'app-order-list',
  standalone: false,
  
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.css'
})
export class OrderListComponent implements OnInit{

  constructor(private sharedService:SharedService){}

  boughtProductArray:Product[]=[];

  ngOnInit(): void {
    this.boughtProductArray = this.sharedService.getBoughtProducts();
  }

  cancelOrder(product:Product):void{
    this.sharedService.cancelOrder(product);
    this.boughtProductArray=this.sharedService.getBoughtProducts();
  }


}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { CustomerGuard } from '../auth/customer.guard';
import { OrderListComponent } from './order-list/order-list.component';


const routes: Routes = [
  {path:'order-details', component:OrderDetailsComponent, canActivate:[CustomerGuard]},
  {path:'order-list',component:OrderListComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrderRoutingModule { }

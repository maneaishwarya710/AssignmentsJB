import { Component, OnInit } from '@angular/core';
import { SharedService } from '../../shared/shared.service';
import { CommonModule } from '@angular/common';

interface Product {
  name: string;
  id: number;
  details: string;
  price: number;
  rating: number;
}

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  standalone:false,
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  productArray: Product[] = [];
  favProductArray: Product[] = [];
  BoughtProductArray:Product[]=[];

  constructor(private sharedService: SharedService) {}

  ngOnInit() {
    this.productArray = this.sharedService.getData();
    this.favProductArray = this.sharedService.getFavProducts();
    this.BoughtProductArray=this.sharedService.getBoughtProducts();
  }

  addProduct(product: Product): void {
    this.sharedService.addProduct(product);
    this.favProductArray = this.sharedService.getFavProducts(); 
  }

  removeProduct(product: Product): void {
    this.sharedService.removeProduct(product);
    this.favProductArray = this.sharedService.getFavProducts(); 
  }

  buyProduct(product:Product):void{
    this.sharedService.buyProduct(product);
    this.BoughtProductArray=this.sharedService.getBoughtProducts();
  }
}
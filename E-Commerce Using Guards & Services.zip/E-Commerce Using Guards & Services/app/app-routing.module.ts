import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserModule } from './user/user.module';
import { OrderModule } from './order/order.module';
import { ProductModule } from './product/product.module';
import { LoginComponent } from './user/login/login.component';

const routes: Routes = [
  {path:'user', loadChildren:()=>import('./user/user.module').then(m=>m.UserModule)},
  {path:'order', loadChildren:()=>import('./order/order.module').then(m=>m.OrderModule)},
  {path:'product', loadChildren:()=>import('./product/product.module').then(m=>m.ProductModule)},
  {path:'security', loadChildren:()=>import('./security/security.module').then(m=>m.SecurityModule)},
  {path:'admin', loadChildren:()=>import('./admin/admin.module').then(m=>m.AdminModule)},
  {path:'', component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

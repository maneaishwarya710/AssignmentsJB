import { ActivatedRouteSnapshot, CanActivateFn, GuardResult, MaybeAsync, Router, RouterStateSnapshot } from '@angular/router';
import { CanActivate } from '@angular/router';
import { AuthService } from './auth.service';
import { Injectable } from '@angular/core';
import { Role } from './role.enum';

@Injectable({
  providedIn:"root"
})
export class AdminGuard implements CanActivate{
  constructor(private authService:AuthService, private router:Router){}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const roles: Role[] = [Role.Admin]; 
        if (this.authService.isUserAuthenticated(roles)) {
          return true;
        } else {
          this.router.navigate(['/login']);
          return false;
        }
  }
}
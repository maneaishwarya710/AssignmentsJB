import { Injectable } from '@angular/core';
import { Role } from './role.enum';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private route: Router) { 
    if (this.isBrowser()) {
      localStorage.setItem('isLoggedIn', 'false');
    }
  }

  login(role: Role) {
    if (this.isBrowser()) {
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('role', JSON.stringify(Role[role]));
    }
  }

  isUserAuthenticated(roles: Role[]): boolean {
    if (this.isBrowser()) {
      const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  
      if (!isLoggedIn) {
        alert("First Login!");
        this.route.navigate(['/login']);
        return false;
      } else {
        const roleString = localStorage.getItem('role');
        if (roleString) {
          const role: Role = JSON.parse(roleString) as Role;
  
          if (roles.includes(role)) {
            return true;
          }
        }
  
        this.route.navigate(['/login']);
        alert("Sorry! You don't have access!")
        return false;
      }
    }
    return false;
  }
  

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }
}

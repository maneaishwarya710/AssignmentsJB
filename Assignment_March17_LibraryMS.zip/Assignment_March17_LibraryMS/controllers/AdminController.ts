import { Request, Response } from 'express';
import { AdminService } from '../Services/adminServices';
import { Book } from '../models/book.model';

const adminService = new AdminService();

class AdminController {
    async addBook(req: Request, res: Response): Promise<void> {
        try {
            const book = new Book(0, req.body.title, req.body.author, req.body.isbn, req.body.availableCopies);
            const newBook = await adminService.addBook(book);
            res.status(201).json(newBook);
        } catch (error) {
            res.status(500).json({ message: 'Error adding book', error });
        }
    }

    async deleteBook(req: Request, res: Response): Promise<void> {
        try {
            const bookId = Number(req.params.id);
            await adminService.deleteBook(bookId);
            res.status(200).json({ message: 'Book Deleted' });
        } catch (error) {
            res.status(500).json({ message: 'Error Deleting Book', error });
        }
    }

    async updateBook(req:Request, res:Response):Promise<void>{
        try {
            const { id, availableCopies } = req.body;
    
            // Validate input data
            if (typeof id !== 'number' || typeof availableCopies !== 'number') {
                res.status(400).json({ error: 'Invalid input data' });
                return;
            }
    
            // Call the service method to update the book
            await adminService.updateBook(id, availableCopies);
    
            // Send a success response
            res.status(200).json({ message: 'Book updated successfully' });
        } catch (error) {
            // Handle errors
            console.error('Error updating book:', error);
            res.status(500).json({ error: 'An error occurred while updating the book' });
        }
    }
}

export { AdminController};

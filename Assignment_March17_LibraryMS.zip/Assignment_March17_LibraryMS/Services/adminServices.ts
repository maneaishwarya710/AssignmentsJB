import { AdminRepository } from '../Repositories/adminRepo';
import { User } from '../models/user.model';
import { Book } from '../models/book.model';
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const SECRET_KEY = "af7cf309a4493a97b7e24c866bd6f5e7893f564d55325cf5b8d11747c31a0c8f";
class AdminService {
    private adminRepository = new AdminRepository();

    async addBook(book: Book): Promise<Book> {
        return await this.adminRepository.addBook(book);
    }

    async deleteBook(id: number): Promise<void> {
        await this.adminRepository.deleteBook(id);
    }

    async updateBook(id:number, availableCopies:number): Promise<void> {
        await this.adminRepository.updateBook(id, availableCopies);
    }
}

export { AdminService };

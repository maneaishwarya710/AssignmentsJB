import { StudentRepository } from '../Repositories/studentRepo';
import { User } from '../models/user.model';
import { Book } from '../models/book.model';
import { BorrowedBooks } from '../models/borrowedBooks';
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const SECRET_KEY = "af7cf309a4493a97b7e24c866bd6f5e7893f564d55325cf5b8d11747c31a0c8f";
class StudentService {
    private studentRepository = new StudentRepository();

    async searchBook(title:string): Promise<Book> {
        return await this.studentRepository.searchBook(title);
    }

    async ViewBook(): Promise<Book[] | null> {
        return await this.studentRepository.viewBook();
    }

    async borrowBook(bookId:number, title:string, userId:number){
        await this.studentRepository.borrowBook(bookId, title, userId);
    }

    async returnBook(bookId:number,userId:number){
        await this.studentRepository.returnBook(bookId,userId);
    }
}

export { StudentService };

import { UserRepository } from "../Repositories/userRepo";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const userRepository = new UserRepository();
const SECRET_KEY = "160afb01793ab948c242d2e51e6b880734c1710aaf37601dd3af21c45546647b";

class AuthService {
    static async createUser(username: string, password: string, role: string) {
        const hashedPassword = await bcrypt.hash(password, 10);
        return await userRepository.createUser(username, hashedPassword, role);
    }

    static async loginUser(username: string, password: string) {
        const user = await userRepository.getUserByUsername(username);
        if (!user) throw new Error("User not found");

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) throw new Error("Invalid credentials");

        const token = jwt.sign({ username: user.username, role: user.role }, SECRET_KEY, { expiresIn: "1h" });
        return { user, token };
    }

    async getUserByUsername(username:string){
        return await userRepository.getUserByUsername(username)
    }
}

export { AuthService };
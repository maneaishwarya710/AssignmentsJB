import { Router } from 'express';
import { StudentController } from '../controllers/studentController';
import  {authenticateUser,roleBasedAuth}  from '../middleware/authMiddleware';
const studentRouter = Router();
const studentController = new StudentController();

studentRouter.get('/search/title',authenticateUser,roleBasedAuth(["Student"]) ,  studentController.searchBook);
studentRouter.get('/view',(req, res) => studentController.viewBook(req, res));
studentRouter.put('/borrow', (req, res) => studentController.borrowBook(req, res));
studentRouter.put('/return', (req, res) => studentController.returnBook(req, res));

export default studentRouter;
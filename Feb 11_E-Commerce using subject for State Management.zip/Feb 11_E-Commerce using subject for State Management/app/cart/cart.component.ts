import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { Product } from '../product.model';

@Component({
  selector: 'app-cart',
  standalone: false,
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit {
  items: Product[] = [];
  CartList: Product[]=[];

  constructor(private cartService: CartService) {}

  ngOnInit(): void {
    this.cartService.items$.subscribe((items) => {
      this.items = items;
    }),
    this.cartService.cart$.subscribe((items)=>{
      this.CartList=items;
    })
  }

  removeItem(index: number) {
    this.cartService.removeItem(index);
  }

  clearCart(){
    this.cartService.clearCart();
  }
}

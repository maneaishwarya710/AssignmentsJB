import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Product } from './product.model';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  
  private items: Product[] = [
    {id: 1, name: 'Cycle', price: 6000},
    {id: 2, name: 'Laptop', price: 78000},
    {id: 3, name: 'Pen', price: 40},
    {id: 4, name: 'Notebook', price: 100},
  ];

  private itemsSubject = new BehaviorSubject<Product[]>(this.items);
  items$ = this.itemsSubject.asObservable();

  private cart: Product[] = [];
  private cartSubject = new BehaviorSubject<Product[]>(this.cart);
  cart$ = this.cartSubject.asObservable();

  addItem(item: Product) {
    this.cart.push(item);
    this.cartSubject.next(this.cart);
  }

  removeItem(index: number) {
    this.cart.splice(index, 1);
    this.cartSubject.next(this.cart);
  }

  clearCart() {
    this.cart = [];
    this.cartSubject.next(this.cart);
  }
}
import { Component } from '@angular/core';
import { CartService } from '../cart.service';
import { Product } from '../product.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  standalone: false,
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent {
  constructor(private cartService:CartService, private router:Router){}
  ProductList: Product[]=[];
  CartList: Product[]=[];

  ngOnInit(){
    this.cartService.items$.subscribe((items)=>{
      this.ProductList=items;
    }),
    this.cartService.cart$.subscribe((items)=>{
      this.CartList=items;
    })
  }

  addCart(product:Product){
    this.cartService.addItem(product);
    this.router.navigate(['/cart']);
  }
}

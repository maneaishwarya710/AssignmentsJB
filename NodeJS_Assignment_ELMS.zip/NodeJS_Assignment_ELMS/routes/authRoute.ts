const expr = require("express");
const authController = require("../controllers/authController");
const authRouter = expr.Router();
authRouter.post("/register", authController.register);
authRouter.post("/login", authController.login); 
module.exports = authRouter;
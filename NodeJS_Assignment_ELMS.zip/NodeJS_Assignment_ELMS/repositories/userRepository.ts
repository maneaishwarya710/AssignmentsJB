// async createUser(name: string, email: string, password: string) {
//     const pool = await poolPromise;
//     const result = await pool
//     .request()
//     .input("name", sql_.VarChar, name)
//     .input("email", sql_.VarChar, email)
//     .input("password", sql_.VarChar, password)
//     .query("INSERT INTO Users (name, email, password) VALUES (@name, 
//     @email, @password)");
//     return result;
//     }
    
import express from 'express';
import leaveRoutes from './routes/leaveRoutes';
import { poolPromise } from './config/database';
const authRouter=require('./services/authService');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());

app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api', leaveRoutes);
app.use("/auth", authRouter);


// Test database connection
poolPromise.then(() => {
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
}).catch((error) => {
    console.error('Unable to connect to the database:', error);
});

export default app;

class Leave {
    constructor(
        public id: number,
        public employeeId: number,
        public startDate: Date,
        public endDate: Date,
        public leaveType: string, 
        public status: string,    
        public reason: string
    ) {}
}

export { Leave };


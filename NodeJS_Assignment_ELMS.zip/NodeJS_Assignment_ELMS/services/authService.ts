const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const userAuthRepository = require("../repositories/userRepository");
const SECRET_KEY = "af7cf309a4493a97b7e24c866bd6f5e7893f564d55325cf5b8d11747c31a0c8f";
class AuthService {
static async registerUser(name: any, email: any, password: any) {
const hashedPassword = await bcrypt.hash(password, 10);
return await userAuthRepository.createUser(name, email, hashedPassword);
}
static async loginUser(email: any, password: any) {
const user = await userAuthRepository.getUserByEmail(email);
if (!user) throw new Error("User not found");
const isPasswordValid = await bcrypt.compare(password, user.password);
if (!isPasswordValid) throw new Error("Invalid credentials");
const token = jwt.sign({ name: user.name, email: user.email }, SECRET_KEY, 
{ expiresIn: "1h" });
return { user, token };
}
}
module.exports = AuthService;
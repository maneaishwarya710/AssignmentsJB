import { LeaveRepository } from '../repositories/leaveRepo';
import { Leave } from '../models/leaveModel';
import { Employee } from '../models/employeeModel';
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const SECRET_KEY = "af7cf309a4493a97b7e24c866bd6f5e7893f564d55325cf5b8d11747c31a0c8f";
class LeaveService {
    private leaveRepository = new LeaveRepository();

    async applyLeave(leave: Leave): Promise<Leave> {
        return await this.leaveRepository.createLeave(leave);
    }

    async getLeaveHistory(employeeId: number): Promise<Leave[]> {
        // const user = await userAuthRepository.getUserByEmail(email);
        const leaves=await this.leaveRepository.getLeavesByEmployeeId(employeeId);
        if (!leaves) throw new Error("Leaves not found");
        const isEmpIdValid = await bcrypt.compare(employeeId, leaves.employeeId);
        if (!isEmpIdValid) throw new Error("Invalid credentials");
        const token = jwt.sign({ name: Employee.name, email: Employee.email }, SECRET_KEY, 
        { expiresIn: "1h" });
        return { user, token };
        
    }

    async getPendingLeaves(): Promise<Leave[]> {
        return await this.leaveRepository.getPendingLeaves();
    }

    async approveLeave(leaveId: number): Promise<void> {
        const leave=await this.leaveRepository.updateLeaveStatus(leaveId, 'Approved');
        if (!leave) throw new Error("Leaves not found");
        const isEmpIdValid = await bcrypt.compare(employeeId, leaves.employeeId);
        if (!isEmpIdValid) throw new Error("Invalid credentials");
        const token = jwt.sign({ name: Employee.name, email: Employee.email }, SECRET_KEY, 
        { expiresIn: "1h" });
        return { user, token };
    }

    async rejectLeave(leaveId: number): Promise<void> {
        await this.leaveRepository.updateLeaveStatus(leaveId, 'Rejected');
    }

    async getAllLeaves(): Promise<Leave[]> {
        return await this.leaveRepository.getAllLeaves();
    }
}

export { LeaveService };

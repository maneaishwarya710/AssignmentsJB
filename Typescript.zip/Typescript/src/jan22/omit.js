var newUser2 = { age: 19 };
console.log(newUser2);

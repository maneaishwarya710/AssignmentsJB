var newUser1 = { name: "Kavya", id: 22 };
console.log(newUser1);

// const form=document.createElement("form");
// const input=document.createElement("input");
// const submitButton=document.createElement("button");

// submitButton.textContent="submit";
// form.appendChild(input);
// form.appendChild(submitButton);
// form.appendChild(input);
// document.body.appendChild(form);

// input.addEventListener("input",(event:input)=>{
//     const target=event.target as HTMLInputElement;
//     console.log(`current input value: ${target.value}` );
// });

// input.addEventListener("submit",(event:submit)=>{
//     const target=event.target as HTMLInputElement;
//     console.log(`current input value: ${target.value}` );
// });


var greet = function (name) {
    return "Hello,".concat(name, "!Welcome to typescript.");
};
console.log(greet("Nisha"));

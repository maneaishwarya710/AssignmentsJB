"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addNums = addNums;
function addNums(a, b) {
    return a + b;
}

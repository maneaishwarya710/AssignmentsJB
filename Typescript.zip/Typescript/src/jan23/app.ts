import {addNums} from "./mathUtl";
console.log(addNums(99,67));

//<reference path="mathOperations.ts" />


// import {MathOperations} from "./nmsp";
// console.log(MathOperations.addNums(12,22));
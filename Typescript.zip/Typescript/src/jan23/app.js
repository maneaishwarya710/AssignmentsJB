"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mathUtl_1 = require("./mathUtl");
console.log((0, mathUtl_1.addNums)(99, 67));
//<reference path="mathOperations.ts" />
// import {MathOperations} from "./nmsp";
// console.log(MathOperations.addNums(12,22));
